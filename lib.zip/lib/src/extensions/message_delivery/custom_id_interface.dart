abstract class CustomIdInterface {
  CustomIdInterface addCustomId(String id);
  String getCustomId();
}
