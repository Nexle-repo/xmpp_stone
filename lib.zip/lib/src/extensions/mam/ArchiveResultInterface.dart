import 'package:xmpp_stone/src/elements/XmppElement.dart';

abstract class ArchiveResultInterface {
  XmppElement? getArchiveResult();
  XmppElement? getArchiveMessage();
}
