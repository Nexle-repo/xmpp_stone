class ChangeMemberRoleData {
  final String userJid;
  final String role;
  ChangeMemberRoleData(this.userJid, this.role);
}
