import 'package:xmpp_stone/src/elements/XmppElement.dart';

abstract class SentInterface {
  XmppElement? getSent();
}
