class PinChatData {
  final String chatId;
  final bool pinned;

  PinChatData({required this.chatId, required this.pinned});
}
