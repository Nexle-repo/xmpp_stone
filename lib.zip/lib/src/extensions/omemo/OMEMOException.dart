import 'package:xmpp_stone/src/exception/XmppException.dart';

class InvalidDeviceListException extends XmppException {}

class ErrorGetDevicesException extends XmppException {}

class ErrorPublishDeviceException extends XmppException {}
