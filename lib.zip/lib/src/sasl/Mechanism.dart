abstract class Mechanism {}
