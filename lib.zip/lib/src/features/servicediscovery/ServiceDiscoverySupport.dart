const List<String> SERVICE_DISCOVERY_SUPPORT_LIST = [
  'http://jabber.org/protocol/chatstates',
];
