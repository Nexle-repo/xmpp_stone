abstract class StreamErrorApi {
  void init();
}
